package demo;

public class Demo1 {

	public static void main(String[] ar) 
	String str1 =new String("TECHNOLOGY");
	String str2 =new String("TECHNOLOGY");
	if(str1==str2)
	{
		System.out.println("str1 ==str2:true");
	}
	
	else if (str1.contentEquals(str2))
	{
		System.out.println("str1 equals str2: true");
    }
	else
	{
		System.out.println("false");
	}

}
}