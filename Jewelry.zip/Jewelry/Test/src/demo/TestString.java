package demo;

public class TestString 
{
	public static void main(String args[])
	{
		String str=new String("hello everybody");
		System.out.println(str.substring(5));
	}

}
