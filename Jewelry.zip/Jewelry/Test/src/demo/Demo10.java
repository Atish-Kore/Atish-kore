package demo;

public class Demo10 
{
	void DemoMethod()
	{
		System.out.println("No parameters");
	}
	
	void DemoMethod(double a,double b)
	{
		System.out.println("This is double method");
	}
	
	void DemoMethod(int a,int b)
	{
		System.out.println("This is the integer method");
	}

	public static void main(String[] args) 
	{
		Demo10 ob=new Demo10();
		ob.DemoMethod();
		ob.DemoMethod(20,10);
		ob.DemoMethod(123.2,1.99);
	
}

}
